%% Generation of a random Multiband signal
% This code generates a real-valued multiband signal at random.
%%

function [x,a,X] = rdn_MB_signal_generation(ns,T,B,Nt)
% rdn_MB_signal_generation Randomly Generate a Multiband signal
% 
% [x,a,X] = rdn_MB_signal_generation(ns,T,B,Nt)
% ns: number of spectral bands
% T: Sampling time [s]
% B: width of the spectral bands [Hz]
% Nt: Number of samples
%
% x= samples in time domain
% a= location of the bands
% X= FFT of the signal


ns=floor(ns/2);
while true
    % Determine location of the bands
    a=sort(rand(ns,1))*(0.5/T-B);
    if length(a)>1
        if min(abs(diff(a)))>B %ensure that there is no overlapping
            break;
        end
    else
        break;
    end
end
b=a+B;

% Initialize FFT of the signal
X=zeros(1,Nt);

% determine indicies for a and b
if mod(Nt,2)
    idx_a=ceil(a*T*(Nt-1));
    idx_b=floor(b*T*(Nt-1));
else
    idx_a=ceil(a*T*Nt);
    idx_b=floor(b*T*Nt);
end

% Generate random FFT signal for each non-zero band
for i=1:ns
    X(idx_a(i):idx_b(i))=(rand*3+2)*[1,1i]*randn(2,idx_b(i)-idx_a(i)+1);
    % Complete for the negative frequencies
    X(Nt+2-(idx_a(i):idx_b(i)))=conj(X(idx_a(i):idx_b(i)));
end
% Ensure that X if the FFT of a real-valued signal 
X(1)=real(X(1));
if ~mod(Nt,2)
    X(Nt/2+1)=real(X(Nt/2+1));
end
% obtain time domain signal
x=real(ifft(X));

end

%%
% Programed by Ramon A. Delgado on Feb 2012 in MATLAB R2011b