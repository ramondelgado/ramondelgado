%% Recursive Estimation of eigenvalues, eigenvectors and frequency support
% This code Update the estimates of the Eigenvalues, eigenvectors and the
% support based on the current estimate of the covariance matrix R
%%
function [ b,Eigenvectors,Eigenvalues,n_est ] = recursive_support(R,initial_Eigenvectors,initial_Eigenvalues,values,nb,ns,a)
%RECURSIVE_SUPPORT Recursive support estimation, for multiband signals
%   Detailed explanation goes here


n=chk_inputs(R,initial_Eigenvectors,initial_Eigenvalues,ns,a);
gamma=1e-2;

% Update eigenvalues and eigenvectors estimates 
[Eigenvectors,Eigenvalues] ...
    = my_resa(initial_Eigenvectors,initial_Eigenvalues,R,gamma);
Eigenvalues=real(Eigenvalues);
% ensure descend order of the eigenvalues
[~,idx]=sort(Eigenvalues,'descend');

% Estimate the size of the signal subspace
norm_sum_eig=Eigenvalues(idx)/sum(Eigenvalues);
rd=sum(norm_sum_eig(1:ns));
ne=n-sum(norm_sum_eig<1/n); 

% Estimate support using MUSIC
[b,n_peaks]=my_music(Eigenvectors(:,idx),a,values,ns,nb);

n_est=[rd;ne;n_peaks];
end

%% Check inputs variables
% Ensura that the inputs variables have the right dimensions

function n=chk_inputs(R,Q0,Lambda0,ns,a)
% check dimensions of Q0, Lambda0 and y

nr=size(R);
nq=size(Q0);
nl=size(Lambda0);


if (nq(1)~=nq(2))||(nl(1)<=nl(2))|| (nr(1)~=nr(2))
    error('Eigenvector matrix must be square, and y a column vector');
end
if (nq(1)~=nl(1))||(nq(1)~=nr(1))
    error('dimensions of Eigenvector matrix, Eigenvalues vector and y must agree');
end

% check that ns is a valid number.

if (ns>=nq(1))
    error('Number of signal must be less than the number of sampling channels');
end

n=nq(1);

end

%%
% Programed by Ramon A. Delgado on Feb 2012 in MATLAB R2011b    