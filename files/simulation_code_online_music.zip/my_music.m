%% MUSIC algorithm implementation
% This code implements the MUSIC algorithm. There is some especial
% considerations (such that the signal is real-valued in the time domain).
%%
function [b,n_peaks] = my_music(V,a,values,ns,nb)
%MY_MUSIC Estimation using MUSIC algorithm
%

nv=size(V,1);
% find Noise Subspace
NoiseV=V(:,2*ns+1:nv);

% % Evaluate Function 
Pmu=zeros(length(values),1);
for t=1:length(values)
    tmp_den=NoiseV'*a(values(t));
    Pmu(t)=1/real(tmp_den'*tmp_den);
end

%Use symmetry of the FFT of real-valued signals  
J=Pmu+Pmu(end:-1:1);

% Obtain larget values of the function
[largest,indices]=sort(J,'descend');

b=zeros(nb,1);
b(1:nb)=sort(values(indices(1:nb)));


% Estimate number of significative values of Pmu 
cumulative=cumsum(largest)/sum(largest);
n_peaks=find(cumulative>0.85,1);
if isempty(n_peaks)
    n_peaks=0;
end

end

%%
% Programed by Ramon A. Delgado on Feb 2012 for MATLAB R2011b   