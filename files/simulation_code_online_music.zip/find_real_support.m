%% Find frequency support of a multiband signal 
% This function find the frequency support of a multiband signal, that will
% be sampled using a multi coset sampling.
%%
function [supp,energy,values]=find_real_support(x,L)

Nt=length(x);
m=Nt/L;

if rem(m,1)
    m=floor(m);
end

% Calculate FFT of the signal
Fx=1/sqrt(Nt)*fft(x);

% reorganize FFT such that the (negative frequencies) be before that the
% (positive frequencies)
if isreal(x)
    Fx_t=Fx;
    if mod(Nt,2)
        Fx(1:(Nt-1)/2)=Fx_t((Nt+1)/2+1:Nt);
        Fx((Nt+1)/2:Nt)=Fx_t(1:(Nt+1)/2);
    else
        Fx(1:Nt/2)=Fx_t(Nt/2+1:Nt);
        Fx(Nt/2+1:Nt)=Fx_t(1:Nt/2);
    end
    
    % determidne the value of the bins of the support
    if mod(L,2)
        values=-(L-1)/2:(L-1)/2;
    else
        values=-(L)/2:(L)/2-1;
    end
else
    values=0:L-1;
end

% Determine energy for each frequency bin
energy=zeros(L,1);
for r=1:L
    energy(r)=sum(abs(Fx((r-1)*m+1:r*m)).^2);
end
energy=energy/sum(energy);

% Determine non zero energy bins 
[energy_sorted,indices]=sort(energy,'descend');
idx=find(cumsum(energy_sorted)>0.98,1);

% Determine the indicies of the non-zero
if idx>1
    supp=values(indices(1:idx));
else
    supp=values(indices(1));
end

supp=supp(:);

%%
% Programed by Ramon A. Delgado on Feb 2012 in MATLAB R2011b    