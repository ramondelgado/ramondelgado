%% Add Gaussian noise to a signal
% This function add Gaussian noise to a signal
%%
function y = add_gaussian_noise(x,SNR)
%ADD_GAUSIAN_NOISE Add Gaussian Noise to a Signal
%   y = add_gaussian_noise(x,SNR)
%   x= noise free signal
%   SNR= Signal to noise ratio SNR= 10*log10(||x||/||noise||)

% Get realization of the noise
noise=randn(size(x));
% scale to match to the SNR
scalenoise=norm(x)/norm(noise)/sqrt(10^(SNR/10));
% add noise
y=x+scalenoise*noise;

end

%%
% Programed by Ramon A. Delgado on Feb 2012 in MATLAB R2011b    