%% Sampling using a multi coset sampling scheme
% This function implements a multicoset samplt, given the nyquist samples.
%%
function [z_ideal,z_filtered]=multi_coset_sampling(xt,sampling_pattern,L,T)
%GENDATA [y,A,x]=gendata(xt,cc,L,T)
% generate the data for blind multiband signal reconstruction,
%Inputs:
%   xt: time signal
%   cc: sampling pattern
%   L: period of the sampling pattern in Nyquist rate samples
%Outputs
%   z_ideal: ideal multi coset samples
%   y0f: non-ideal multicoset samples

[n1,n2]=size(sampling_pattern);
if n1>n2
    sampling_pattern=sampling_pattern.';
end

p=length(sampling_pattern);
Nt=length(xt);
nc=floor(Nt/L);

% get samples of each sampling channel
xc=reshape(xt(1:L*floor(Nt/L)),L,[]);
yc=xc(sampling_pattern,:).'; % shifted samples (aligned)

%----- Generate signals for each channel--------

% a) zero padded signals
y0=zeros(p,(nc+1)*L);
idx=(0:nc-1)*L;
for t=1:p
    y0(t,idx+sampling_pattern(t))=xc(sampling_pattern(t),:);
end

% b) zero padded and filtered

y_filtered=zeros(p,size(yc,1)*L); % initialize interpolated output
z_filtered=zeros(p,size(yc,1)*L); % initialize interpolated and delayed output

for i=1:p
  y_filtered(i,:)=interp(yc(:,i),L,2,1); % interpolate by L
  % delay for sampling pattern c(i)
  z_filtered(i,sampling_pattern(i):size(yc,1)*L) ...
      = y_filtered(i,1:size(yc,1)*L-(sampling_pattern(i))+1); 
end


% c) filtered with an ideal filter (sinc interpolation)  

y_interpolated=zeros(p,size(yc,1)*L); % initialize interpolated output
z_ideal=zeros(p,size(yc,1)*L); % initialize interpolated and delayed output

for i=1:p
  y_interpolated(i,:)=interpft(yc(:,i),size(yc,1)*L); % interpolate by L
  % delay for sampling pattern c(i)
  z_ideal(i,sampling_pattern(i):size(yc,1)*L) ...
      = y_interpolated(i,1:size(yc,1)*L-(sampling_pattern(i))+1); 
end

%%
% Programed by Ramon A. Delgado on Feb 2012 in MATLAB R2011b    