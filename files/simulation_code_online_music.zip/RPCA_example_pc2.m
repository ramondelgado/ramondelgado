%% On-line MUSIC algorithm for blind multiband signal reconstruction
% This code implement the numerical
% example of the journal paper "An on-line MUSIC algorithm for blind
% multiband signal reconstruction" submitted to IEEE Signal processing
% letters.
%%

clear
clc
close all
%%% Simulation parameters
% First we define 
ns=8;                   % Number of Bands
L=53;                   % Size of sparse vector
pvalues=[32,36,40,52];  % size of measurement vector
Nt=2^9*L;               % Total number of measurements in time;
T=1/(20e9);             % Base frequency of multi coset sampling
B=floor(0.95/(L*T));    % Frequency width of each band
N_signals=100;          % Number of Monte-Carlo simulations

results=cell(N_signals,1);

initial_time=clock;
%matlabpool open local 2

parfor s=1:N_signals
    
%% Generate Multiband Signal
% Generate first half of the samples and
% save the true support of the signal
    x1 = rdn_MB_signal_generation(ns,T,B,Nt/2);
    supp1=find_real_support(x1,L);
    
    % Generate the second half of the samples
    % with a diffrent support
    while true
        
        x2 = rdn_MB_signal_generation(ns,T,B,Nt/2);
        supp2=find_real_support(x2,L);
        
        if length(supp1)==length(setdiff(supp1,supp2))
            break;
        end
    end
    
    x=[x1,x2];

    % add noise (if required)
    x_m = add_gaussian_noise(x,Inf);
    

    n_est_p=cell(length(pvalues),1);
    x_hat_p=cell(length(pvalues),1);
    b_hat_p=cell(length(pvalues),1);
    
% We simulate for different values sampling pattern sizes $p$.
    for r=1:length(pvalues)
        
        %%% Multi coset sampling 
        p=pvalues(r);
        sampling_pattern=1:p;
        [y_ideal,y0f]=multi_coset_sampling(x_m,sampling_pattern,L,T);
        
        
%% On-line Signal Reconstruction
% Now we implement the proposed algorithm for
% on-line signal reconstruction of multiband signals
        
        nb=2*ns; % number of support estimates on the MUSIC algorithm
        n_est=zeros(3,Nt);% Estimated number of signals based on Eigenvalues
        reset_time=zeros(1,Nt); 
        x_hat=zeros(1,Nt);
        b=zeros(nb,Nt);

        R=zeros(p);% Initialize Covariance Matrix
        Eigenvectors=eye(p)/p;% Initialize eigenvector estimates
        Eigenvalues=diag(y_ideal(:,1)*y_ideal(:,1)');% Init. eigenvalues
        b_hat_prev=zeros(nb,1)+0.1;
        
        z=exp(1i*2*pi/L);
        a=@(x) (z.^((sampling_pattern-1).'*(x))); % single column of A
        
        
        if isreal(x)
            if mod(L,2) % Determine if L is odd
                values=-((L-1)/2):floor((L-1)/2);
            else
                values=-(L/2):(L/2-1); % for real-valued signals
            end
        else
            values=0:L-1; % for complex-valued signals
        end
        
        last_reset=0;
        sugg_reset_count=0;
        Lambda=1;
        for k=1:Nt
            y=y_ideal(:,k);
            
            
            R=Lambda*R+y*y';% update Covariance estimation

            [b(:,k),Eigenvectors,Eigenvalues,n_est(:,k)]...
                =recursive_support(R,Eigenvectors,Eigenvalues...
                ,values,nb,ns,a);% Update Eigenvalues, Eigenvectors and support
            
            
            % % %--------------Change Detection feature----------------
            %
            %                 if k>1
            %
            %                 if n_est(1,k)-n_est(1,k-1)<=0
            %                     sugg_reset_count=sugg_reset_count+1;
            %                 else
            %                      sugg_reset_count=0;
            %                 end
            %
            %                 if sugg_reset_count>=200
            %                     if sugg_reset_count==200
            %                         last_ne=n_est(2,k);
            %                         last_rd=n_est(1,k);
            %                     end
            %                     if n_est(2,k)-last_ne>=1
            %                         reset_time(k)=1;
            %                         sugg_reset_count=0;
            %                         R=y*y';
            %                     else
            %                         reset_time(k)=0;
            %                     end
            %                 else
            %                     reset_time(k)=0;
            %                 end
            %
            %                 end
            %
            %                 if (n_est(2,k)>nb+1)&&(last_reset+50*L<k)
            %                     R=y*y';
            %                     last_reset=k;
            %                 end
            % % %-------------------------------------------------------
            
            b_hat=unique(b(:,k));
            
            %calculate Pseudo inverse only when the estimate b change
            if (length(b_hat)~=length(unique(union(b_hat,b_hat_prev)))) ...
                    || length(b_hat)~=length(b_hat_prev)
                pinvA=pinv(exp(1i*2*pi/L*(sampling_pattern-1).'*b_hat.'));
            end
            
            %Reconstruct signal based in the cuurent estimate of b.
            b_hat_prev=b_hat;
            x_hat(k)=recursive_MB_reconstruction(y,pinvA,b_hat,L,k-1);
            
        end
        
        if isreal(x) % ensure that x is real-valued
            x_hat=real(x_hat);
        end
  
        %Store data for the current sampling pattern.
        n_est_p(r)={n_est};
        x_hat_p(r)={x_hat};
        b_hat_p(r)={b};
       
    end
    disp(s)
    
    %Store data for the current signal 
    signal_sim=struct('x_hat',x_hat_p,'b_hat',b_hat_p,'x',x...
        ,'pvalues',pvalues);
    results(s)={signal_sim};    
end
%matlabpool close
final_time=clock;

%Save simulation Results
sim_parameters=struct('L',L,'T',T,'p',pvalues,'B',B...
    ,'Simulation_Time',etime(final_time,initial_time));
save(['../data/Example_MB_' date '.mat'],'sim_parameters','results');


%% Post Simulation Analysis
% Processing the results.
% This part of the code only needs the variables 'sim_parameters' and
% 'results'.

%Get simulation parameters
L=sim_parameters.L;
N_signals=length(results);
pvalues=results{1}(1).pvalues;
Nt=length(results{1}(1).x);
Nte=length(results{1}(1).x_hat);
Np=length(pvalues);

%Initialize matrices
success=zeros(Np,Nte);
error_in_time=zeros(Np,Nte);
signal_norm=zeros(N_signals,1);

% Get data for each Monte-Carlo simulation
for s=1:N_signals

    if isempty(results{s}); N_signals=s-1; break; end;
    x=results{s}(1).x;
    
    % find the frequency support of the signal
    supp1=find_real_support(x(1:Nt/2),L);
    supp2=find_real_support(x(Nt/2+1:Nt),L);
    
    signal_norm(s)=norm(x);
    N_supp1=length(supp1);
    N_supp2=length(supp2);
    disp(s)
    % Get data for each sampling rate
    for r=1:Np 
        b_hat{r}=results{s}(r).b_hat;
        x_hat{r}=results{s}(r).x_hat;
        % determine if the support was recovered at each time
        count1=(sum(ismember(b_hat{r}(:,1:Nte-Nt/2),supp1))==N_supp1);
        count2=(sum(ismember(b_hat{r}(:,Nte-Nt/2+1:Nte),supp2))==N_supp2);
        count=[count1,count2];
        
        success(r,:)=success(r,:)+count;
        e=abs(x_hat{r}-x(Nt-Nte+1:Nt));
        % Calculate weighted average of the error
        error_in_time(r,:)=error_in_time(r,:)+e/norm(x(Nt-Nte+1:Nt));
    end
end

signal_norm=signal_norm(1:N_signals);
    
%% Generate plots

% Generate legend strings
str_legend=cell(1,Np);
for k=1:Np
    str_legend{k}=num2str(pvalues(k));
end

% Plot weighted average of the error in time
figure(12)
plot(error_in_time');
y_axis=ylim;
xlim([1 Nte])
% add a line to indicate the change in the support 
line(Nte-floor(Nt/2)*ones(20,1),linspace(y_axis(1),y_axis(2),20)');
xlabel('Time samples')
title('Error in time')
legend(str_legend,'Location','Best')

% Plot Percentage of success on estimate the support
figure(13)
plot(success','.')
ylim([0 N_signals])
xlim([1 Nte])
% add a line to indicate the change in the support 
line(Nte-floor(Nt/2)*ones(20,1),linspace(0,N_signals,20)');
xlabel('Time samples')
title('Empirical success')
legend(str_legend,'Location','Best')

%%
% Programed by Ramon A. Delgado on Feb 2012 in MATLAB R2011b