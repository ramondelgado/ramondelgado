%% Reconstruction of the signal
% Recosntruct the original signal based on the estimated frequency support 
%%
function x=recursive_MB_reconstruction(y,pinvA,b,L,k)
% RECURSIVE_MB_RECONSTRUCTION recursively reconstruct a multiband signal
% x=recursive_MB_reconstruction(y,psiA,b,L,k)
%
% y: time samples from the multi coset sampling
% pinvA: Pseudo-inverse of the A matrix
% b: estimated spectral support
% L: decimation factor in the Multi coset sampling
% k: sample number

% time samples of each non zero frequency slot.
 xr=pinvA*y;
    
% modulation
x=exp(1i*2*pi/L*b'*k)*xr;
end
%%
% Programed by Ramon A. Delgado on Feb 2012 using MATLAB R2011b   