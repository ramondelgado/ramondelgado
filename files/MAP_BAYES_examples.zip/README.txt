
This package contains the MATLAB code to run the examples in the paper 
Ramon .A Delgado and Graham .C. Goodwin 
" A Combined and Bayesian scheme for Finite Data and/or Moving Horizon Estimation.
submitted for publication on 2013.

The package contains:
- Code for running the examples in the paper
- Results of precomputed Full Bayesian Filtering.
-A Toy example that could be helpful in the implementation on the method in a different problem.
 

For implementation of the code on a different problem, 
please consider a more suitable optimisation method. 
------------------------------------
Running the examples
----------------------------------
The Run a numerical examples run the m-file called Simulation_parameters.m
Note that the Full Bayesian Part has been already computed.
In case that you want to deploy Full Bayesian Filtering change the the variable 
fb_filename in Simulation_parameters.m  




----------------------------------  
Reducing the execution time in the calculation 
for the Deterministic grid method
------------------------------------ 

The execution time for the functions to compute Full Bayesias Grid and to compute skewness can be reduced 
by using a mex-file. 

In the instruction that I provide I assume that you have done
the setup of you compiler, if you don't,
may be in the following steps you will be asked to select a compiler.
For more information about this please search in internet: 
matlab Building MEX-Files

To create a  this please follow the following in MATLAB
1) run the script build_mex_file.m
3) Ensure that the mex files are in the right folder.
4) Now you can use run the code as has been described in "Running the examples" above.


last time edited: Apr 2013

Ramon A. Delgado
ramon.delgado@uon.edu.au


