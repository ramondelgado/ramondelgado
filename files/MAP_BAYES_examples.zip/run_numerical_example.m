function [data,results] = run_numerical_example(selected_model,Tsim,Delta,Nh,Nq,Npf,FB_file_name)
%RUN_NUMERICAL_EXAMPLE Run numerical example
%   Usage: run_numerical_example(selected_model,Tsim,Delta,Nh,Nq,Npf,FB_file_name)

% Get measurements and model
[data,fh,con,Q,R]=simulate_model(selected_model,Tsim,Delta);

nx=size(data.x,1);
N=size(data.y,2);

% Offline step of the algorithms
% Get quantization for the standad multivariate normal distribution
[Pu,Cu]=Initialize_MAP_Bayes_quantization(Nq,nx);

% Create Storage variables
D_MB=init_storage(N,nx,'distribution',length(Pu));
D_CPF=init_storage(N,nx,'distribution',Npf);
D_EKF=init_storage(N,nx,'point',[]);



% Set Initial condition for each algorithm
switch selected_model
    case 0
        x0=[3;1];
        P0=eye(nx);
    case {1,2}
        x0=1;
        P0=1/12*(2-0)^2;
end

% -----MAP-Bayes
D_MB.name='MAP-Bayes'; D_MB.short_name='MB';
% set initial condition
switch selected_model
    case 0
        D_MB.tmp.Cx0=chol(P0,'lower')*Cu+repmat(x0,1,size(Cu,2));
        D_MB.tmp.Px0=Pu(:);
    case {1,2}
        D_MB.tmp.Cx0=linspace(0,2,size(Cu,2));
        D_MB.tmp.Px0=ones(size(Cu,2),1)/size(Cu,2);
end
D_MB.fh=fh;             % function handles
D_MB.Q=Q;   D_MB.R=R;   % Noise variances
D_MB.opt=con;           %optimization constraints
D_MB.opt.options=optimset('Display','off');
D_MB.lambda=1;          % initial condition weight

% -----EKF-Bayes
D_EB=D_MB;
D_EB.name='EKF-Bayes'; D_EB.short_name='EB';

% -----Constrained Particle Filter
D_CPF.name='Constrained Particle Filter'; D_CPF.short_name='CPF';

% set initial condition
switch selected_model
    case 0
        D_CPF.tmp.x0=chol(P0,'lower')*randn(nx,Npf)+repmat(x0,1,Npf);
         D_CPF.tmp.q=ones(Npf,1)/Npf;
    case {1,2}
        D_CPF.tmp.x0=2*rand(1,Npf);
        D_CPF.tmp.q=ones(Npf,1)/Npf;
end

D_CPF.fh=fh;             % function handles
D_CPF.opt=con;           %optimization constraints
D_CPF.opt.options=optimset('Display','off');


% -----Extended Kalman Filter
D_EKF.name='Extended Kalman Filter'; D_EKF.short_name='EKF';
D_EKF.tmp.x0=x0;       % initial mean
D_EKF.tmp.P0=P0;       % initial variance
D_EKF.fh=fh;           % function handles
D_EKF.Q=Q;  D_EKF.R=R; % Noise Variances

% -----Full Bayesian over a deterministic grid
if exist(FB_file_name,'file') % check is FB has been done
   
    load(FB_file_name,'D_FB','data');
    results{5}=D_FB;
else
    D_FB.name='Full Bayesian'; D_FB.short_name='FB';
    D_FB.tmp.x0=x0;     % initial mean
    D_FB.tmp.P0=P0;     % initial variance
    switch selected_model
        case 0
            D_FB.apri_dist='normal'; %initial distribution type
            D_FB.N_grid=[50,70];    % number of elements in the grid 
            D_FB.x_min=floor(min(data.x,[],2)-1); % min value in the grid
            D_FB.x_max=ceil(max(data.x,[],2)+1);  % max valu en the grid
        case {1,2}
            D_FB.apri_dist='uniform'; % initial distribution type
            D_FB.x_min=-1;      % min value in the grid
            D_FB.x_max=4;       % max value in the grid
            D_FB.N_grid=(D_FB.x_max-D_FB.x_min)*1e2+1;  % number of elements in the grid
            
    end
    D_FB.type='distribution'; 
    
    
    D_FB.fh=fh;             % function handles
    D_FB.opt=con;           %optimization constraints
    D_FB.opt.options=optimset('Display','off');
    
    % Deploy Full Bayesian
    tic
    D_FB=full_bayes_grid(D_FB,data.y);
    t_tmp=toc;
    
    % Compute average running time
    D_FB.t_avg=t_tmp/length(data.y);
    
    % save results
    save(FB_file_name,'D_FB','data')
    results{5}=D_FB;
end

% Run algorithms
fprintf('\n---------------------------------\n');
fprintf('Simulation Start\n');
fprintf('\n Displaying sample time where the last is N = %d \n',N);
for k=1:N;
    
    % Algorithms running over an Horizon
    if (mod(k,Nh)==0) && (k>=Nh)
        % set horizon mesurements
        y_rh=data.y(:,k-Nh+1:k);
        
        [D_MB]=map_bayes_update(D_MB,y_rh,Cu,k);
    end
    % Algorithms Running Sample by Sample
    
    D_CPF=constrained_particle_filter_update(D_CPF,data.y(:,k),k);
    
    D_EKF = extended_kalman_filter_update(D_EKF,data.y(:,k),k);
    
    D_EB = ekf_bayes_update(D_EB,data.y(:,k),Cu,k);
    
    % Display current sample index
    str_fmt=['%' num2str(ceil(log10(N)+0.1)+1) 'd'];
    fprintf(str_fmt,k);
    if ~mod(k,15)
        fprintf('\n');
    end
end
fprintf('\nSimulation Ended\n');
fprintf('For the MAP-Bayes algorithm  we use N_x = %d  points\n',length(Pu))
fprintf('to approximate the standard Normal distribution\n');
fprintf('\n---------------------------------\n');
results{1}=D_MB;
results{2}=D_CPF;
results{3}=D_EKF;
results{4}=D_EB;
end

%--------------------------------------
%        Generate Samples from model
%--------------------------------------
function [data,fh,con,Q,R]=simulate_model(selected_model,Tsim,Delta)
switch selected_model
    case 0 % two states batch reactor model
        % --- Parameters ---
        x0=[3;1];               % initial condition
        p.QfV=0.4;              % constant
        p.k=0.16;               % constant
        p.Caf=1;                % constant
        p.Cbf=0;                % constant
        p.disturbance_status=0; % Status of the disturbance at time 5s (active=1, inactive=0).
        p.disturbance_magnitude=4;
        
        % Define process and measurement noises
        Q=1e-2*eye(2);
        R=1e-2;
        p.time=(0:Delta:Tsim)';
        p.process_noise=(chol(Q,'lower')*randn(size(Q,1),length(p.time)))';
        p.measurement_noise=(chol(R,'lower')*randn(size(R,1),length(p.time)))';
        
        % Simulate model
        options=odeset('MaxStep',Delta/2);
        
        [T,x_sim]=ode45(@(t,x) (Batch_Reactor(t,x,p)),0:Delta:Tsim,x0,options);
        
        % get state values and obtain measurement
        x=x_sim(2:end,1:2).';
        y=sum(x,1)+p.measurement_noise(2:end,:).';
        t=T(2:end);
        % % % Generate function to be used by the algorithms
        
        % state equation (continuous-time version)
        f_c=@(x) ([-2*p.k*x(1,:).^2+p.QfV*p.Caf;...
            p.k*x(1,:).^2+p.QfV*p.Cbf]);
        fh.h=@(x) (x(1,:)+x(2,:));
        % state equation (discrete-time version)
        fh.f=@(x) (x+Delta*f_c(x));
        
        % PDF evaluation
        fh.pw=@(x)(real(exp(-0.5*quad_expr(x,Q)))); % Normal distribution
        fh.pv=@(x)(real(exp(-0.5*quad_expr(x,R))));
        
        % Draw samples from the distribution
        fh.pw_s=@(Ns)(chol(Q)*randn(size(Q,1),Ns));%Normal distribution
        
        % function to check state constraints
        fh.con=@(x) sum(x>=repmat(zeros(2,1),1,size(x,2)),1)==2;
        con.UB=[Inf;Inf];
        con.LB=zeros(2,1);
        
    case 1 % Water Tank model
        x0=0.9;
        Q=5e-1*eye(1);
        R=1e-2;
        p.a=1;
        p.time=(0:Delta:Tsim)';
        mean_q=sqrt(0.95);
        p.q_input=max((chol(Q,'lower')*randn(size(Q,1),length(p.time)))'+mean_q,0);
        
        p.min_level=0;
        p.max_level=1;
        
        % function to check state constraints
        con.UB=p.max_level;
        con.LB=p.min_level;
        fh.con=@(x) (x>=repmat(p.min_level,1,size(x,2)))&(x<=repmat(p.max_level,1,size(x,2)));
        
        % Simulate model
        t_span=0:Delta:Tsim;
        options=odeset('MaxStep',Delta/2,'Events',@(t,y) (detect_invalid(y,fh.con)));
        T=[];
        x_sim=[];
        t_end=0;
        opt_options=optimset('Display','off');
        alpha=0.99;
        while t_end<Tsim
            %simulate until hit a constraint
            [T_out,x_out]=ode45(@(t,x) (Water_Tank(t,x,p)),t_span,x0,options);
            
            % save partial simulation
            T=[T;T_out];
            x_sim=[x_sim;x_out];
            
            % set next simulation time
            t_end=T_out(end);
            t_span(t_span<=t_end)=[];
            
            % set initial point
            x0= lsqlin(eye(length(x0)),x_out(end,:).',[],[],[],[],con.LB,con.UB,[],opt_options);
            x0=real(x0);
            
            % Handle spaecial case
            if length(t_span)==1
                t_span=[t_span-alpha*Delta/5,t_span];
                alpha=alpha.^2;
            end
        end
        
        % get state values and obtain measurement
        t=Delta:Delta:Tsim;
        idx=knnsearch(T(:),t(:));
        x=x_sim(idx,:).';
        y=x+chol(R,'lower')*randn(size(R,1),length(t));
        
        % % % Generate function to be used by the algorithms
        fh.f=@(x) (x-Delta*p.a*sqrt(max(x,0)));
        fh.h=@(x) (x);
        
        % PDF evaluation
        fh.pw=@(x)(real(exp(-0.5*quad_expr(x-mean_q,Q)))); % Normal distribution
        fh.pv=@(x)(real(exp(-0.5*quad_expr(x,R))));
        
        % Draw samples from the distribution
        fh.pw_s=@(Ns)(chol(Q)*randn(size(Q,1),Ns));%Normal distribution
        
    case 2 % Two-radious Water Tank model
        x0=0;
        Q=1e-1*eye(1);
        R=1e-2;
        p.r0=sqrt(1/pi); % radious of the output hole 
        p.r1=sqrt(10)*sqrt(1/pi); % radious of the upper part of the tank 
        p.a=1;        
        p.G=9.80665;  %Standard gravitational acceleration on Earth m/s^2
        p.time=(0:Delta:Tsim)';
        
        % define input Caudal
        mean_q=sqrt(pi^2*p.r0^4*2*p.G-Q);
        p.q_input=max((chol(Q,'lower')*randn(size(Q,1),length(p.time)))'+mean_q,0);
        
        % Define min, max, and change of radious level
        p.min_level=0;
        p.max_level=Inf;
        p.change_r=(Q+mean_q^2)/(pi^2*p.r0^4*2*p.G);
        
        % function to check state constraints
        con.UB=p.max_level;
        con.LB=p.min_level;
        fh.con=@(x) (x>=repmat(p.min_level,1,size(x,2)))&(x<=repmat(p.max_level,1,size(x,2)));
        
        % Simulate model
        t_span=0:Delta:Tsim;
        options=odeset('MaxStep',Delta/2,'NonNegative',1);
        T=[];
        x_sim=[];
        t_end=0;
        opt_options=optimset('Display','off');
        alpha=0.99;
        while t_end<Tsim
            %simulate until hit a constraint
            [T_out,x_out]=ode45(@(t,x) (general_Tank(t,x,p)),t_span,x0,options);
            
            % save partial simulation
            T=[T;T_out];
            x_sim=[x_sim;x_out];
            
            % set next simulation time
            t_end=T_out(end);
            t_span(t_span<=t_end)=[];
            
            % set initial point
            x0= lsqlin(eye(length(x0)),x_out(end,:).',[],[],[],[],con.LB,con.UB,[],opt_options);
            x0=real(x0);
            
            % Handle spaecial case
            if length(t_span)==1
                t_span=[t_span-alpha*Delta/5,t_span];
                alpha=alpha.^2;
            end
        end
        
        % get state values and obtain measurement
        t=Delta:Delta:Tsim;
        idx=knnsearch(T(:),t(:));
        x=x_sim(idx,:).';
        
        
        % % % Generate function to be used by the algorithms
        k1=pi*p.r0^2*sqrt(2*p.G);       % constant used in the function
        change_v=p.change_r*pi*p.r0^2; % volumet at which the radious change
        fh.f=@(x) (x+Delta*(mean_q-k1*sqrt((x<=repmat(change_v,1,size(x,2))).*(x/(pi*p.r0^2))...
            +(x>repmat(change_v,1,size(x,2))).*(x/(pi*p.r1^2)+p.change_r*(1-p.r0^2/p.r1^2)))));
        fh.h=@(x) (((x<=repmat(change_v,1,size(x,2))).*(x/(pi*p.r0^2))...
            +(x>repmat(change_v,1,size(x,2))).*(x/(p.r1^2*pi)+p.change_r*(1-p.r0^2/p.r1^2))));
        
        y=fh.h(x)+chol(R,'lower')*randn(size(R,1),length(t));
        % PDF evaluation
        fh.pw=@(x)(real(exp(-0.5*quad_expr(x,Q)))); % Normal distribution
        fh.pv=@(x)(real(exp(-0.5*quad_expr(x,R))));
        
        % Draw samples from the distribution
        fh.pw_s=@(Ns)(chol(Q,'lower')*randn(size(Q,1),Ns));%Normal distribution
   
    otherwise
        error('Model not defined');
end
data.y=y;
data.x=x;
data.t=t;

end
%----------------------------------------------
function x=Batch_Reactor(t,x,p)
%Differenntial equation for Batch reactor

% Reaction evolution
x(1:2)=[-2;1]*p.k*x(1)+p.QfV*[p.Caf;p.Cbf];

% Add perturbances
x(1:2)=x(1:2)+interp1(p.time,p.process_noise,t,'nearest').';

% Unmodelled_disturbance
if ((t>=5)&&(t<=5.2)&&(p.disturbance_status==1))
    x(1:2)=x(1:2)+p.disturbance_magnitude;
end

end
%----------------------------------------------
function dx=Water_Tank(t,x,p)
% Differential equation for water tank model

% Compute input flow
q_in=interp1(p.time,p.q_input,t,'nearest').';

% Level evolution
if x>0
    dx=q_in-p.a*sqrt(x);
else
    dx=q_in;
end

end
%----------------------------------------------
function dx=general_Tank(t,x,p)
% Differential equation for water tank model

% Compute input flow
q_in=interp1(p.time,p.q_input,t,'nearest').';

% Volume evolution
if x>0
    if x>pi*p.r0^2*p.change_r        
        dx=(q_in-pi*p.r0^2*sqrt(2*p.G*(x/(pi*p.r1^2)+p.change_r*(1-p.r0^2/p.r1^2))));
    else
        dx=(q_in-pi*p.r0^2*sqrt(2*p.G*x/(pi*p.r0^2)));
    end
else
    dx=q_in;
end

end
%----------------------------------------------
function [value,isterminal,direction]=detect_invalid(y,check_constraints)
value=check_constraints(y.')*1;
direction=0;
isterminal=1;
end

%----------------------------------------------
%      Utility functions
%-----------------------------------------------
function D=init_storage(N,nx,option,Nv)
% Initialize variables to store the results
switch lower(option)
    case 'distribution'
        D.type='distribution';
        D.x=nan(nx*Nv,N);
        D.p=nan(Nv,N);
        
    case 'point'
        D.type='point';
        D.x=nan(nx,N);
        D.p=ones(1,N);
    otherwise
        error('The option is not valid.')
        
end
% Time statistics
D.t_avg=0;
D.t_min=1/eps;
D.t_max=0;
D.counter=0;
end
%-----------------------------------------------
function A=jaccsd(fun,x)
% JACCSD Jacobian through complex step differentiation
% [z J] = jaccsd(f,x)
% z = f(x)
% J = f'(x)
%
z=fun(x);
n=numel(x);
m=numel(z);
A=zeros(m,n);
h=n*eps;
for k=1:n
    x1=x;
    x1(k)=x1(k)+h*1i;
    A(:,k)=imag(fun(x1))/h;
end
end
%-----------------------------------------------
function D=update_time_stats(D,t)
        D.counter=D.counter+1;
        %Update average time
        D.t_avg=((D.counter-1)*D.t_avg+t)/D.counter;
        %update maximum
        if t>D.t_max;D.t_max=t;end
        % update minimum
        if t<D.t_min;D.t_min=t;end

end

%----------------------------------------------
%      functions used in MAP-Bayes estimation
%-----------------------------------------------
function [Px,Cx]=Initialize_MAP_Bayes_quantization(Nx,nx)
%Initialize_MAP_Bayes Generate a point distribution 
% that approximate an standard Normal distribution
Ntr=60000;
u=randn(nx,Ntr);% training sequence for w
[Cx,Px] = find_lattice(u,nx,Nx);

end
%-----------------------------------------------
function [Ce,Pe] = find_lattice(u,nx,n_max)
%FIND_LATTICE Return a grid that is truncated to by a ball, 
% where the size of the ball is selected by minimizing the distortion respect
% to a standard multivariate normal distribution.

% % % % Get points inside a ball
% generate an square grid
m=ceil((n_max+1)^(1/nx));
if ~mod(m,2);m=m+1;end
x_grid=repmat(linspace(-1,1,m),nx,1);
v=zeros(nx,m^nx);
for jj=1:m^nx
    v(:,jj)=get_x(jj,nx,x_grid);
end

% find a ball that encloses at most n_max vectors 
D=sqrt(sum(v.^2,1));
r_values=linspace(0,1,2*m);
for ii=1:length(r_values)
    if sum(D<=r_values(ii))<=n_max
        r_idx=ii;
    else
        break
    end 
end
idx=D<=r_values(r_idx);
v=v(:,idx);

% % % Compute optimal distance of the points
% this is scale the grid based on the distortion
c=1;
options=optimset('Display','off');
c=fminunc(@(x) (eval_distortion(x,u,v)),c,options);
Ce=c*v;

% Find the probability mass of each point
nu=size(u,2);
Pe=compute_weights(u,ones(nu,1)/nu,Ce);
end
%-----------------------------------------------
function s=get_x(jj,nx,x_grid)
%Return the value of x given by the index to select a combination of the
%elements in x_grid
pos=jj;
N_grid=zeros(nx,1);
for ii=1:nx
    N_grid(ii)=sum(isfinite(x_grid(ii,:)));
end
s=zeros(nx,1);
for ii=1:nx
    idx=mod(pos-1,N_grid(ii))+1;
    s(ii)=x_grid(ii,idx);
    if ii<nx
        pos=ceil(pos/N_grid(ii));
    end
end
end
%-----------------------------------------------
function d=eval_distortion(c,u,Ce)
% Evaluate the Distortion introduced by the quantization
nc2=size(Ce,2);
 D=zeros(nc2,size(u,2));
    for k=1:nc2
        tmp=u-repmat(c*Ce(:,k),1,size(u,2));
        D(k,:)=sum((tmp).^2,1);
    end
    [val]=min(D,[],1);
    d=sum(val);
end
%-----------------------------------------------
function [Pe]=compute_weights(u,P,C)
%COMPUTE_WEIGHTS computes the weights of the partition.
% usage [Ce,Pe]=compute_weights(u,P,C)
%       u: training data
%       P: weights for training data
%       C: centroids

nx=size(u,1);
[nc1,nc2]=size(C);

if nx~=nc1
    error('number of rows of the Centroid and training elements must agree')
end
u(:,sum(~isfinite(u),1)>0)=[];

% Calculate distance to all the centroids
D=zeros(nc2,size(u,2));
for k=1:nc2
    tmp=u-repmat(C(:,k),1,size(u,2));
    D(k,:)=sum((tmp).^2,1);
end

% Assign element to each cell, based in minimum distance
[~,S]=min(D,[],1);

% Compute weight 
Pe=zeros(nc2,1);
for k=1:nc2
    idx=(S==k);
    Pe(k)=sum(P(idx));
end
end

%-----------------------------------------------
function D=map_bayes_update(D,y,Cu,k)
%MAP_BAYES_UPDATE Run the MAP-Bayes algorithm over one horizon
tic

Nh=size(y,2);
mx=size(D.Q,1);
[~,max_idx]=max(D.tmp.Px0);
mu=D.tmp.Cx0(:,max_idx(1));
% [mu]=compute_mean_variance(D.tmp.Cx0,D.tmp.Px0);

% Initial guess for optimization
x_init=zeros(mx,Nh);
for ii=1:Nh
    if ii==1
        x_init(:,ii)=D.fh.f(mu);
    else
        x_init(:,ii)=D.fh.f(x_init(:,ii-1));
    end
end
x_init=x_init(:);

% optimization
options=D.opt.options;
ones_tmp=ones(Nh,1);
x_est_tmp=fmincon(@(x) (eval_cost_MB(x,y,D)),x_init(:),[],[],[],[],kron(ones_tmp,D.opt.LB),kron(ones_tmp,D.opt.UB),[],options);

a=1;
while any(~isfinite(x_est_tmp))
    fprintf('\nlikelihood is zero!!\n')
    D_tmp=D;
    D_tmp.lambda=0;
    x_est_tmp=fmincon(@(x) (eval_cost_MB(x,y,D_tmp)),x_init(:),[],[],[],[],kron(ones_tmp,D.opt.LB),kron(ones_tmp,D.opt.UB),[],options);
    
    if any(~isfinite(x_est_tmp))
        [mu,P0]=compute_mean_variance(D.tmp.Cx0,D.tmp.Px0);
        a=a*10;
        P0=a*P0;
        x_init=zeros(mx,Nh);
        for ii=1:Nh
            [mu,P0]=extended_kalman_filter(D,mu,P0,y(:,ii));
            if(mx==1)
                if mu<0;mu=0;end;
                if P0<0;P0=0;end;
            end
            x_init(:,ii)=mu;
        end
        x_init=x_init(:);
    end
    
end
% Ensure that optimum is a valid point

if any(~D.fh.con(reshape(x_est_tmp,mx,[])))
    
    x_est_tmp=reshape(x_est_tmp,mx,[]);
    
    % find indicies of the invalid points
    invalid_pts=~D.fh.con(x_est_tmp);
    indicies=1:length(invalid_pts);
    indicies=indicies(invalid_pts);
    
    % find nearest valid points
    x_tmp=x_est_tmp(:,indicies);
    ones_tmp=ones(length(indicies),1);
    x_tmp=lsqlin(eye(numel(x_tmp)),x_tmp(:),[],[],[],[],kron(ones_tmp,D.opt.LB),kron(ones_tmp,D.opt.UB),[],D.opt.options);
    x_est_tmp(:,indicies)=reshape(x_tmp,mx,[]);
    
    x_est_tmp=x_est_tmp(:);
end

% Deploy Full Bayesian
[D.tmp.Cx0,D.tmp.Px0,Cx_bayes,Px_bayes] = compute_aposteriori_MB(reshape(x_est_tmp,mx,[]),y,D,Cu);

running_time=toc/Nh;

% Save Results
for ii=k-Nh+1:k
    D.x(1:numel(Cx_bayes{ii-(k-Nh)}),ii)=Cx_bayes{ii-(k-Nh)}(:);
    D.p(1:numel(Px_bayes{ii-(k-Nh)}),ii)=Px_bayes{ii-(k-Nh)}(:);
end

% update time stats
D=update_time_stats(D,running_time);
end
%-----------------------------------------------
function [p] = eval_cost_MB(x,y,D)
%EVAL_COST_MB Evaluate marginalized probability dist. for MAP-BAyes
%example (the negative logarithm of the prob.)
%  Usage: [p,x_final,P_final,x_bayes,Py] = eval_prob(x,Cx0,Px0,Cw,Pw,y,Q,R,f,h)
%   Inputs: x: MAP estimates as column vectors
%           Cx0: Vector representing the Dist. of x_0
%           Px0: Prob. of each vector on Cx0
%           Cw: Vector representing the dist. of state noise
%           Pw: Prob. of each vector in Cw
%           y: measurements vector.
%           Q: covariance matrix of the state noise.
%           R: covariance matrix of measurement noise.
%           f: function in state update equation
%           h: function in measurement equation
%  Outputs: p: probalitity value (J' in the paper)
%           x_final: vector in the a-post. dist. (x_N in the paper)
%           P_final: prob. corresponding to the vectors in x_final
%           x_bayes: analog to x_final for x_(N-1)
%           Py: prob corresponding to the vector of x_bayes
%   Date: Aug 2012
%   Author: R.A. Delgado

% check size of input matrices
if size(x,2)==1
    mx=size(D.Q,1);
    m=length(x)/mx;
    x=reshape(x,mx,m);
end

N=size(y,2);
p=0;

% For each element in the horizon
for k=1:N

    if k==1
        
        % Marginalize over the initial condition

        dx=repmat(x(:,k),1,size(D.tmp.Cx0,2)) - D.fh.f(D.tmp.Cx0);
        p0=D.fh.pw(dx) * D.tmp.Px0(:);
        dy=y(:,k) - D.fh.h(x(:,k));
        if D.lambda>0
            p=p-D.lambda*log(p0)-log(D.fh.pv(dy));
        else
             p=p-log(D.fh.pv(dy));
        end
    else
            % map evaluation
            dx=x(:,k)-D.fh.f(x(:,k-1));
            dy=y(:,k)-D.fh.h(x(:,k));
            p=p+0.5*dx'/D.Q*dx+0.5*dy'/D.R*dy;
            
   
    end
    
end

if ~isfinite(p)
    p=p;
end
end

%-----------------------------------------------
function [mu,sigma]=compute_mean_variance(Cx,Px)
%COMPUTE_MEAN_VARIANCE compute the mean and variance of a point
%distribution.
mu=Cx*Px(:);
mx=size(Cx,1);
sigma=zeros(mx);
sigma_tmp=Cx-repmat(mu,1,size(Cx,2));
for ii=1:size(Cx,2)
    sigma=sigma+Px(ii)*sigma_tmp(:,ii)*sigma_tmp(:,ii)';
end

end
%-----------------------------------------------
function [Cx0,Px0,C_store,P_store] = compute_aposteriori_MB(x,y,D,Cu)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

mx=size(D.Q,1);
N=size(x,2);
A=cell(N,1);
H=cell(N,1);
% Compute variance of the a priori distribution
[~,P0]=compute_mean_variance(D.tmp.Cx0,D.tmp.Px0);
P=P0;
P_store=cell(N,1);
C_store=cell(N,1);
Cx0=D.tmp.Cx0;
Px0=D.tmp.Px0;
for ii=1:N
    % Update covariance using EKF
    A{ii}=jaccsd(D.fh.f,x(:,ii)); 
    P=A{ii}*P*A{ii}'+D.Q;
    H{ii}=jaccsd(D.fh.h,x(:,ii)); 
    P12=P*H{ii}'; 
    [RR,pp]=chol(H{ii}*P12+D.R);
    if pp>0
        pp=0;
    end
    U=P12/RR; 
    P=P-U*U';
    
    % Generate scale vector grid
    L=chol(P,'lower');
    Cx=L*Cu+repmat(x(:,ii),1,size(Cu,2));
    
    % compute a posteriori distribution 
    Px=priv_compute_aposteriori(Cx0,Px0,Cx,y(:,ii),D);
    
    % Check constraints and do clipping 
    [Cx0,Px0]=clipping(Cx,Px,D.fh.con);
    
    %[~,P]=compute_mean_variance(Cx0,Px0);
    
    P_store{ii}=Px0;
    C_store{ii}=Cx0;
end

end

%-----------------------------------------------
function [Px] = priv_compute_aposteriori(Cx0,Px0,Cx,y,D)

m=size(Cx,2);
Px=zeros(m,1);
    for ii=1:m
        dx=repmat(Cx(:,ii),1,size(Cx0,2))-D.fh.f(Cx0);
        Px(ii)=D.fh.pw(dx)*Px0(:);
    end
    dy=repmat(y,1,m)-D.fh.h(Cx);
    Py=D.fh.pv(dy);
    if sum(Px)==0
        Px=Py(:);
    else
        Px=Px.*Py(:);
    end
    Px=Px(:)/sum(Px(:));

end

%-----------------------------------------------
function [Cx,Px]=clipping(Cx,Px,chk_const)

% get valid points indicies
valid_pts=chk_const(Cx);
numbers=1:size(Cx,2);
valid_idx=numbers(valid_pts);

if isempty(valid_idx)
    warning('all points are invalid')
end
invalid_idx=numbers(~valid_pts);

% Assign probability masses of invalid points to the closest valid point
if ~isempty(invalid_idx) && ~isempty(valid_idx) 
    nn_idx=knnsearch(Cx(:,valid_pts)',Cx(:,~valid_pts)');
    for jj=unique(nn_idx')
        Px(valid_idx(jj))=Px(valid_idx(jj))+sum(Px(invalid_idx(nn_idx==jj)));
    end
end

% only return the valid points
Px=Px(valid_idx);
Cx=Cx(:,valid_idx);
end

%----------------------------------------------
%    Functions used by Particle Filtering
%-----------------------------------------------
function D= constrained_particle_filter_update(D,y,k)
filter_type = 'sir'; % or 'sir';

tic
x_prior=cpf_importance_sampling(y,D);

q=cpf_importance_weights(x_prior,y,D);

% Do resampling if needed
if sum(q)>0
    switch lower(filter_type)
        case 'sir'
            x=cpf_resampling(x_prior,q);
            q_next=ones(length(q),1)/length(q);
        case 'sis'
            NT=length(q)/3;
            Neff=1/sum(q.^2);
            if Neff>NT
                x=x_prior;
                q_next=q;
            else
                x=cpf_resampling(x_prior,q);
                q_next=ones(length(q),1)/length(q);
            end
        otherwise
            error('Unknown filter type')
    end
else
    disp('All imporatnce weights are zero!!')
    x=zeros(size(x_prior));
    q_next=ones(length(q),1)/length(q);
end

D.tmp.x0=x;
D.tmp.q=q_next;
running_time=toc;

%Save results
D.x(1:numel(x),k)=x_prior(:);
D.p(1:numel(q),k)=q(:);

% update time stats
D=update_time_stats(D,running_time);
end
%-----------------------------------------------
function x=cpf_importance_sampling(y,D)
%CPF_IMPORTANCE_SAMPLING Importance sampling for constrained Particle
%filter
x=D.tmp.x0;
nx=size(x,1);
N=size(x,2);
method='clipping'; % define how to deal with invalid points

%Unsconstrained Importance sampling
x = feval(D.fh.f,x) + D.fh.pw_s(N);

% Find invalid points
test_constraints=D.fh.con(x);
indicies=1:length(test_constraints);
invalid_idx=indicies(~test_constraints);

% deal with invalid points
switch lower(method)
    case 'clipping'
        if ~isempty(invalid_idx)
            x_tmp=x(:,invalid_idx);
            ones_tmp=ones(length(invalid_idx),1);
            x_tmp=lsqlin(eye(numel(x_tmp)),x_tmp(:),[],[],[],[],kron(ones_tmp,D.opt.LB),kron(ones_tmp,D.opt.UB),[],D.opt.options);
            x(:,invalid_idx)=reshape(x_tmp,nx,[]);
        end
        
    case 'state_deviation_vs_output_error'
        for ii=invalid_idx
            x(:,ii)=fmincon(@(z) (0.5*norm(x(:,ii)-z)^2-log(D.fh.pv(y-D.fh.h(z)))),x(:,ii),[],[],[],[],D.opt.LB,D.opt.UB,[],D.opt.options);
        end
    otherwise
        
end
end
%-----------------------------------------------
function q=cpf_importance_weights(x,y,D)
%CPF_IMPORTANCE_WEIGHTS Contrained Particle Filter Importance Weights

q_prev=D.tmp.q;
% compute weights
dy=repmat(y,1,size(x,2))-D.fh.h(x);
q=D.fh.pv(dy);
q=q(:).*q_prev(:);
% normalize
q=q(:)/sum(q);
end
%-----------------------------------------------
function x=cpf_resampling(x,q)
% CPF_RESAMPLING Contrained Particle Filter Resampling
method='sr'; % select the resampling to be used

N=length(q);
switch lower(method)
    case 'sr'% Systematic resampling
        qc=cumsum(q);
        u=((0:N-1).'+rand(1))/N;
        idx=zeros(1,N);
        kk=1;
        for jj=1:N
            while qc(kk)<u(jj)
                kk=kk+1;
            end
            idx(jj)=kk;
        end
        x=x(:,idx);
    case 'rsr'% Residual Systematic resampling
        idx=zeros(1,N);
        u=rand(1)/N;
        for jj=1:N
            idx(jj)=max(floor(q(jj)-u*N),0)+1;
            u=u+idx(jj)/N-q(jj);
        end
        x=x(:,idx);
    otherwise
        
end
        

end

%----------------------------------------------
%    Functions used by Full Bayesian estimation
%-----------------------------------------------
function [D]=full_bayes_grid(D,y)%pw_eval,pv_eval,f,h,x0,P0,x_min,x_max,N_grid, chk_const)
% FULL_BAYES_GRID Computes Full Bayesian using a fine deterministic grid
% Usage: [apos_p,x_vec]=full_bayes_grid(D,y)
% Inputs and inner variables:   y: measurements vector
%           D.Q: covariance matrix state noise
%           D.R: covariance matrix measuremenmt noise
%           D.fh.f: function in state update equation f(x)
%           D.fh.h: function in output equation h(x)
%           D.x_min: minimum values in the grid
%           D.x_max: maximum value in the grid
%           D.N_grid: number of elements in the grid for each state element
% This function can take several hours (or more than a day) to run.

nx=size(D.tmp.x0,1);
N=size(y,2);

% Number of element in the grid
Npts=prod(D.N_grid);
    
apos_p=zeros(Npts,N);

% Determine grid values
x_val=nan(nx,max(D.N_grid));
for ii=1:nx
    x_val(ii,1:D.N_grid(ii))=linspace(D.x_min(ii),D.x_max(ii),D.N_grid(ii));
end

% contruct vector with all combination of x_values
x_vec=zeros(nx,Npts);
for jj=1:Npts
   x_vec(:,jj)=get_x(jj,nx,x_val);
end

%---Initialise a priori distribution---
% we use zero mean with Gaussian with unitary variance
apri_p=zeros(Npts,1);
switch lower(D.apri_dist)
    case 'normal'
        valid_pts=D.fh.con(x_vec);
         for jj=1:Npts
             apri_p(jj)=exp(-0.5*(x_vec(:,jj)-D.tmp.x0)'/D.tmp.P0*(x_vec(:,jj)-D.tmp.x0));
         end
         apri_p=apri_p/sum(apri_p);
    case 'uniform'
    %---trespase probability from invalid points to nearest valid points.
    % 
        valid_pts=(x_vec>=0)&((x_vec<=2));
        apri_p=valid_pts(:)/sum(valid_pts);
end
%---Compute a posteriori distribution using Chapman-Kolmogorov and Bayes
% rule-------
for k=1:N
    dy=repmat(y(:,k),1,Npts)-D.fh.h(x_vec);
    for ii=1:Npts
        p=0;
        % State update
        if k==1
            p=apri_p(ii);
        else
            dx=repmat(x_vec(:,ii),1,Npts)-D.fh.f(x_vec);
            p=p+(D.fh.pw(dx)*apos_p(:,k-1));

        end
        % Observation update  
        apos_p(ii,k)=p*D.fh.pv(dy(:,ii));
    end
    % nomalisation
    apos_p(:,k)=apos_p(:,k)/sum(apos_p(:,k));
    
    % clipping
%     nn_idx=knnsearch(x_vec(:,valid_pts)',x_vec(:,~valid_pts)');
%     numbers=1:Npts;
%     valid_idx=numbers(valid_pts);
%     invalid_idx=numbers(~valid_pts);
%     for jj=unique(nn_idx')
%         apos_p(valid_idx(jj),k)=apos_p(valid_idx(jj),k)+sum(apos_p(invalid_idx(nn_idx==jj),k));
%     end
%     apos_p(invalid_idx,k)=zeros(length(invalid_idx),1);
    disp([k N])
end

D.x=repmat(x_vec(:),1,N);
D.p=apos_p;

end

%----------------------------------------------
%    Functions used by Extended Kalman Filter
%-----------------------------------------------
function [D] = extended_kalman_filter_update(D,y,k)
tic

[x,P]=extended_kalman_filter(D,D.tmp.x0,D.tmp.P0,y);

running_time=toc;

%Save results
D.x(1:numel(x),k)=x(:);
D.p(1:numel(P),k)=P(:);

% update time stats
D=update_time_stats(D,running_time);
end
%----------------------------------------------
function [x,P]=extended_kalman_filter(D,x0,P0,y)

A=jaccsd(D.fh.f,x0);    %nonlinear update and linearization at current state
x1=real(D.fh.f(x0));
P=A*P0*A'+D.Q;                 %partial update
H=jaccsd(D.fh.h,x1);    %nonlinear measurement and linearization
z1=real(D.fh.h(x1));
P12=P*H';                   %cross covariance
R=chol(H*P12+D.R);            %Cholesky factorization

U=P12/R;                    %K=U/R'; Faster because of back substitution
x=x1+U*(R'\(y-z1));         %Back substitution to get state update
P=P-U*U';                   %Covariance update, U*U'=P12/R/R'*P12'=K*P12.
end

%-----------------------------------------------
%               EKF-BAYES
%---------------------------------------
function D=ekf_bayes_update(D,y,Cu,k)
%MAP_BAYES_UPDATE Run the MAP-Bayes algorithm over one horizon
tic

% mean and variance of the a priori distribution
[x0,P0]=compute_mean_variance(D.tmp.Cx0,D.tmp.Px0);

[x,P]=extended_kalman_filter(D,x0,P0,y);

% Ensure that optimum is a valid point
% if any(~D.fh.con(x))
%     % find nearest valid points
%     x=lsqlin(eye(numel(x)),x,[],[],[],[],D.opt.LB,D.opt.UB,[],D.opt.options);
% end

% Allocate set of points 
[L,pp]=chol(P,'lower');
if pp>0
    [V,DD]=eig(P);
    d=diag(DD);
    d=sqrt(max(d,0));
    L=V*diag(d);
end

Cx=L*Cu+repmat(x,1,size(Cu,2));

% Deploy Full Bayesian on the allocated points
Px=priv_compute_aposteriori(D.tmp.Cx0,D.tmp.Px0,Cx,y,D);

D.tmp.Cx0=Cx;
D.tmp.Px0=Px;

running_time=toc;

% Save Results

D.x(1:numel(Cx),k)=Cx(:);
D.p(1:numel(Px),k)=Px(:);


% update time stats
D=update_time_stats(D,running_time);
end
