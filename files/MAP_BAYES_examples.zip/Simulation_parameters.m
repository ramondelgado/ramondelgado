% Numerical example for the paper
% Ramon A. Delgado and Graham C. Goodwin."A Combined MAP and Bayesian
% Scheme for Finite Data and/or Moving Horizon Estimation"
% submited to Automatica
% Edited March-2013
% coded by: Ramon A. Delgado
% In this code we compare different approaches for constrained nonlinear filtering
% such as EKF, and PF.
% For the MAP-Bayes we use a Block estimation scheme using filtered
% update.

%---- Simulation parameters ---
Nq=30;              % number of vector used to quantize p(x_0)
Npf=100;            % number of particle used by Particle Filter
Ntr=60000;          % Number of samples used for training the VQ
Tsim=10;            % Simulation Time
Delta=0.1;           % Sampling Period

Nh=1;               % size of rolling horizon

warning('off','optim:fminunc:SwitchingMethod');
%--- Model to simulate---
% Select between the predefined models to simulate
% options are:  0: Two states batch reactor
%               1: Tank model simulation 
%               2: Tank with two radii  
selected_model=2;

% Define file name where the data of full bayesian it is or will be stored 
FB_file_name=['Full_bayes_results_' num2str(selected_model) '.mat'];

% Run Example
[data,results] = run_numerical_example(selected_model,Tsim,Delta,Nh,Nq,Npf,FB_file_name);

% Generate some plots and get som other statistics
[analized_results]=analyze_results(data,results{:});

% gerenerate table for paper
table_paper(data,analized_results)

% save results for future reference.
%save(['Simulation_results_' num2str(selected_model) '_' date '.mat'])