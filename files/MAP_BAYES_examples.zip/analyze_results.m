function [results]=analyze_results(data,varargin)
% GENERATE_PLOTS
t=data.t;
y=data.y;
x=data.x;

nx=size(x,1);
fig_numbers=[1 nx+1 nx+2];

% clear figures
if size(x,1)==1; 
    for ii=0:3
        figure(fig_numbers(3)+ii);
        clf(fig_numbers(3)+ii);
        xlabel('Time [s]');
        hold on
    end
end

line_colors=hsv(nargin);
% Plot true state values
for ii=1:nx
    figure(fig_numbers(1)+ii-1)
    clf(fig_numbers(1)+ii-1)
    hold off
    line(t,x(ii,:),'DisplayName','true value','Color',line_colors(1,:))
    title(['Estimated values for x_' num2str(ii)]);
    xlabel('Time [s]')
end
    
if nargin>1
    fprintf('\nMean Square Error\n')
    mse_values=zeros(nargin-1,1);
    
    % plot mean values and get MSE compared again the true state
    for ii=1:nargin-1
        [mse_values(ii),stats]=plot_results(data,varargin{ii},fig_numbers,line_colors(ii+1,:));
        D_tmp=varargin{ii};
        fprintf([D_tmp.short_name '\t%3.2e\n' ],mse_values(ii));
        D_tmp.results.mse=mse_values(ii);
        D_tmp.results.stats=stats;
        varargin{ii}=D_tmp;
    end
    
    % display average running time
    fprintf('\nAverage running time per sample\n')
    fb_flag=false;
    count_dist=0;
    for ii=1:nargin-1
        D_tmp=varargin{ii};
        fprintf([D_tmp.short_name '\t%3.2e\n' ],D_tmp.t_avg);
            
        if strcmpi(D_tmp.short_name,'fb') % determine if full bayesian was perfomed
            fb_flag=true;
            fb_idx=ii;
        else
            if strcmpi(D_tmp.type,'distribution')
               count_dist=count_dist+1; 
            end
        end
    end
    
    % Compute values that depends on Full Bayesian results
    if fb_flag 
        % compute Hellinger divergence
        hell_div=nan(1,length(data.t));
        Dfb=varargin{fb_idx};
        figure(fig_numbers(2))
        clf
        title('Hellinger Divergence')
        xlabel('Time [s]')
        for jj=1:nargin-1
            D=varargin{jj};
            if (strcmpi(D.type,'distribution') && (jj~=fb_idx))
                for ii=1:length(data.y)
                    hell_div(ii)=hellinger_divergence(reshape(D.x(:,ii),nx,[]).',D.p(:,ii),reshape(Dfb.x(:,ii),nx,[]).',Dfb.p(:,ii),1,'both');
                end
                D.results.hellinger=hell_div;
                varargin{jj}=D;
                line(data.t,hell_div,'DisplayName',D.short_name,'Color',line_colors(jj+1,:))
                legend('Location','Best')
                hold on
            end
        end
        hold off
    end
    results=varargin;
else
    results=0;
end
end
%-----------------------------------------------
function [mse_val,stats]=plot_results(data,D,fig_numbers,line_color)
nx=size(data.x,1);
N=size(data.y,2);
switch lower(D.type)
    case 'point'
        mse_val=norm(D.x-data.x)^2/N;
        for ii=1:nx
            figure(fig_numbers(1)-1+ii)
            hold on
            line(data.t,D.x(ii,:),'DisplayName',D.short_name,'Color',line_color)
            legend('Location','Best')
            hold off
        end
        
        if nx==1
            stats=struct('mean',D.x.','mode',D.x.','variance',D.p.','skew',zeros(size(D.p.')));
            %plot mean
            figure(fig_numbers(3))
            title('Mean')
            line(data.t,D.x.','DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
            
            %plot mode
            figure(fig_numbers(3)+1)
            title('Mode')
            line(data.t,D.x.','DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
            
            %plot variance
            figure(fig_numbers(3)+2)
            title('Variance')
            line(data.t,D.p.','DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
        else
            stats.mean=D.x;
            stats.mode=D.x;
        end
    case 'distribution'
        % compute mean and mode
        idx=(0:nx:nx*(floor(size(D.x,1)/nx)-1))';
        x_mean=zeros(nx,size(D.x,2));
        x_mode=zeros(nx,size(D.x,2));
        [~,idx_mode]=max(D.p,[],1);
        for ii=1:nx
            for ll=1:size(D.x,2),
                n_valid=sum(isfinite(D.p(:,ll)));
                x_valid=D.x(ii+idx,ll);
                x_mean(ii,ll)=x_valid(1:n_valid).'*D.p(1:n_valid,ll);
                x_tmp=reshape(D.x(:,ll),nx,[]);
                x_mode(ii,ll)=x_tmp(ii,idx_mode(ll));
            end
            figure(fig_numbers(1)-1+ii)
            hold on
            line(data.t,x_mean(ii,:),'DisplayName',D.short_name,'Color',line_color)
            line(data.t,x_mode(ii,:),'DisplayName',[D.short_name ' mode'],'Color',line_color,'LineStyle','--')
            legend('Location','Best')
            hold off
        end
        % compute MSE compare to true state
        mse_val=norm(x_mean-data.x)^2/N;
        
        if nx==1
            % Compute Mean, Mode, Variance and Skewness
            mu=zeros(size(D.x,2),1);
            mode_value=zeros(size(D.x,2),1);
            sigma=zeros(size(D.x,2),1);
            skew_value=zeros(size(D.x,2),1);
            
            % For speed-up computation, uncomment the following lines
            % and also the lines and the end of the "for" loop 
            % Also chage the "for" word by a "parfor"
            % Valid for dual core computers
            %if size(D.p,1)>100
            %    matlabpool open local 2
            %end
            for ll=1:size(D.x,2),
                n_valid=sum(isfinite(D.p(:,ll)));
                x_valid=reshape(D.x(:,ll),nx,[]);
                x_valid=x_valid(:,1:n_valid);
                p_valid=D.p(1:n_valid,ll);
                [mu(ll),mode_value(ll),sigma(ll),skew_value(ll)]=compute_mean_mode_variance_skew(x_valid,p_valid);
                
            end
            % if size(D.p,1)>100
            %     matlabpool close
            % end
            
            stats=struct('mean',mu,'variance',sigma,'mode',mode_value,'skew',skew_value);
            
            %plot mean
            figure(fig_numbers(3))
            title('Mean')
            line(data.t,mu,'DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
            
            %plot mode
            figure(fig_numbers(3)+1)
            title('Mode')
            line(data.t,mode_value,'DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
            
            %plot variance
            figure(fig_numbers(3)+2)
            title('Variance')
            line(data.t,sigma,'DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
            
            %plot Skewness
            figure(fig_numbers(3)+3)
            title('Skewness')
            line(data.t,skew_value,'DisplayName',[D.short_name],'Color',line_color)
            legend('Location','Best')
        else
            stats.mean=x_mean;
            stats.mode=x_mode;
            %stats=[];
        end
        
    otherwise
        error('Unknown data type\n')
end
end
%----------------------------------------------
%    Functions used to analyse the results
%-----------------------------------------------
function [D] = hellinger_divergence(x1,p1,x2,p2,k,method)
%hellinger_knn Computes Hellinger divergence. The interpolation of the probability
% density function is made by using nearest neighbour interpolation,
% or by grouping particles based on nearest neigbour.


% Compute divergence by using zero-hold or linear interpolation
% Use this method when the elements in x1 is small compared 
% with the number of element in x2 
if (strcmpi(method,'knn')==0) || (strcmpi(method,'both')==0)
    %computes maximum distance in first data set to determine range of validity
    %of the nearest neighbour interpolation
    [~,M]=knnsearch(x1,x1,'K',2);
    max_distance=max(M(:));
    
    % Interpolate probability 1 by using Nearest Neighbour interpolation
    [IDX_K,M]=knnsearch(x1,x2,'K',k);
    p_int=zeros(size(x2,1),1);
    
    if k>1
        % Linear Interpolation
        for ii=1:size(x2,1)
            y=p1(IDX_K(ii,:));
            A=y(:)'*pinv(x1(IDX_K(ii,:),:)');
            p_int(ii)=A*x2(ii,:)';
            if p_int(ii)<0
                p_int(ii)=0;
            end
        end
    else
        % Zero order interpolation
        idx_values=unique(IDX_K);
        p_int=zeros(size(IDX_K,1),1);
        % If more than one point is neigbour,
        % devide the weight in the number of neighbour
        for ii=idx_values(:)'
            idx=(M<max_distance)&(IDX_K==ii);
            p_int(idx)=p1(ii)/sum(idx);
        end
    end
    
    % Compute
    D_knn=1/sqrt(2)*sqrt(sum((sqrt(p_int(:))-sqrt(p2(:))).^2));
end

% Interpolate PDF by grouping particles (Use this method if the number of
%elements of x1 is much larger than in x2)
if (strcmpi(method,'nn')==0) || (strcmpi(method,'both')==0)
    [p_int]=compute_weights(x1',p1,x2');
    p_int=p_int/sum(p_int);
    D_nn=1/sqrt(2)*sqrt(sum((sqrt(p_int(:))-sqrt(p2(:))).^2));
end

% Determine value to return
if (strcmpi(method,'both')==0)
    D=min(D_knn,D_nn);
else
    if (strcmpi(method,'nn')==0)
        D=D_nn;
    else
        if (strcmpi(method,'knn')==0)
            D=D_knn;
        else
            error('Unknown method, please use "knn", "nn" or "both"\n');
        end
    end
end

end
%-----------------------------------------------
function [Pe]=compute_weights(u,P,C)
%COMPUTE_WEIGHTS computes the weights of the partition.
% usage [Ce,Pe]=compute_weights(u,P,C)
%       u: training data
%       P: weights for training data
%       C: centroids

nx=size(u,1);
[nc1,nc2]=size(C);

if nx~=nc1
    error('number of rows of the Centroid and training elements must agree')
end
u(:,sum(~isfinite(u),1)>0)=[];

% Calculate distance to all the centroids
D=zeros(nc2,size(u,2));
for k=1:nc2
    tmp=u-repmat(C(:,k),1,size(u,2));
    D(k,:)=sum((tmp).^2,1);
end

% Assign element to each cell, based in minimum distance
[~,S]=min(D,[],1);

% Compute weight 
Pe=zeros(nc2,1);
for k=1:nc2
    idx=(S==k);
    Pe(k)=sum(P(idx));
end
end
%-----------------------------------------------`
function [mu,mode_value,sigma,gamma_skew]=compute_mean_mode_variance_skew(Cx,Px)
%COMPUTE_MEAN_VARIANCE compute the mean and variance of a point
%distribution.

mu=Cx*Px(:); % compute mean

[~,mode_idx]=max(Px(:),[],1);
mode_value=Cx(:,mode_idx); % get mode value

% compute Variance
mx=size(Cx,1);
sigma=zeros(mx);
sigma_tmp=Cx-repmat(mu,1,size(Cx,2));
for ii=1:size(Cx,2)
    sigma=sigma+Px(ii)*sigma_tmp(:,ii)*sigma_tmp(:,ii)';
end

% Compute skewness
if nargout==4
    gamma_skew = compute_skewness(Cx,Px,mu,sigma);
end
end
