% This script create a mex file for a function in  a .m file

% generic input matrix
A_mex=coder.typeof(0,[Inf,Inf],1);

% Enable input arguments of variable size
mexcfg = coder.config('mex');
mexcfg.EnableVariableSizing=true;
mexcfg.DynamicMemoryAllocation = 'AllVariableSizeArrays';

% create mex file
codegen quad_expr.m -args {A_mex,A_mex} -config mexcfg
codegen compute_skewness.m -args {A_mex,A_mex,A_mex,A_mex} -config mexcfg