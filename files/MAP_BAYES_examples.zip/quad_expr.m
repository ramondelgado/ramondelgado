function y=quad_expr(x,Q) %#codegen
% QUAD_EXPR This function calculates the quadratic expression
% of the form x_1'/Q*x_1, for each column of a matrix
%
% Usage:  y=quad_expr(x,Q)
%   Inputs: x: a n-by-m matrix [x_1 x_2 .. x_m]
%           Q: a n-by-n covariance matrix
%   output: y: [x_1'/Q*x_1 x_2'/Q*x_2 ...]

N=size(x,2);
y=zeros(1,N);
for ii=1:N
    y(ii)=x(:,ii)'/Q*x(:,ii);
end