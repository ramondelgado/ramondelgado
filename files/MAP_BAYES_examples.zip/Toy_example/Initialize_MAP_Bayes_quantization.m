function [Px,Cx]=Initialize_MAP_Bayes_quantization(Nx,nx)
%Initialize_MAP_Bayes Generate a point distribution 
% that approximate an standard Normal distribution

Ntr=60000;    % Number of samples used for training the VQ
u=randn(nx,Ntr);% training sequence for w
[Cx,Px] = find_lattice(u,nx,Nx);

end
%-----------------------------------------------
function [Ce,Pe] = find_lattice(u,nx,n_max)
%FIND_LATTICE Return a grid that is truncated to by a ball, 
% where the size of the ball is selected by minimizing the distortion respect
% to a standard multivariate normal distribution.

% % % % Get points inside a ball
% generate an square grid
m=ceil((n_max+1)^(1/nx));
if ~mod(m,2);m=m+1;end
x_grid=repmat(linspace(-1,1,m),nx,1);
v=zeros(nx,m^nx);
for jj=1:m^nx
    v(:,jj)=get_x(jj,nx,x_grid);
end

% find a ball that encloses at most n_max vectors 
D=sqrt(sum(v.^2,1));
r_values=linspace(0,1,2*m);
for ii=1:length(r_values)
    if sum(D<=r_values(ii))<=n_max
        r_idx=ii;
    else
        break
    end 
end
idx=D<=r_values(r_idx);
v=v(:,idx);

% % % Compute optimal distance of the points
% this is scale the grid based on the distortion
c=1;
options=optimset('Display','off');
c=fminunc(@(x) (eval_distortion(x,u,v)),c,options);
Ce=c*v;

% Find the probability mass of each point
nu=size(u,2);
Pe=compute_weights(u,ones(nu,1)/nu,Ce);
end
%-----------------------------------------------
function s=get_x(jj,nx,x_grid)
%Return the value of x given by the index to select a combination of the
%elements in x_grid
pos=jj;
N_grid=zeros(nx,1);
for ii=1:nx
    N_grid(ii)=sum(isfinite(x_grid(ii,:)));
end
s=zeros(nx,1);
for ii=1:nx
    idx=mod(pos-1,N_grid(ii))+1;
    s(ii)=x_grid(ii,idx);
    if ii<nx
        pos=ceil(pos/N_grid(ii));
    end
end
end
%-----------------------------------------------
function d=eval_distortion(c,u,Ce)
% Evaluate the Distortion introduced by the quantization
nc2=size(Ce,2);
 D=zeros(nc2,size(u,2));
    for k=1:nc2
        tmp=u-repmat(c*Ce(:,k),1,size(u,2));
        D(k,:)=sum((tmp).^2,1);
    end
    [val]=min(D,[],1);
    d=sum(val);
end
%-----------------------------------------------
function [Pe]=compute_weights(u,P,C)
%COMPUTE_WEIGHTS computes the weights of the partition.
% usage [Ce,Pe]=compute_weights(u,P,C)
%       u: training data
%       P: weights for training data
%       C: centroids

nx=size(u,1);
[nc1,nc2]=size(C);

if nx~=nc1
    error('number of rows of the Centroid and training elements must agree')
end
u(:,sum(~isfinite(u),1)>0)=[];

% Calculate distance to all the centroids
D=zeros(nc2,size(u,2));
for k=1:nc2
    tmp=u-repmat(C(:,k),1,size(u,2));
    D(k,:)=sum((tmp).^2,1);
end

% Assign element to each cell, based in minimum distance
[~,S]=min(D,[],1);

% Compute weight 
Pe=zeros(nc2,1);
for k=1:nc2
    idx=(S==k);
    Pe(k)=sum(P(idx));
end
end

