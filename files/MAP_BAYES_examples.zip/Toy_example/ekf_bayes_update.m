%-----------------------------------------------
%               EKF-BAYES
%---------------------------------------
function [Cx,Px]=ekf_bayes_update(model,Cx0,Px0,y,Cu)
%MAP_BAYES_UPDATE Run the MAP-Bayes algorithm over one horizon

% mean and variance of the a priori distribution
[x0,P0]=compute_mean_variance(Cx0,Px0);

% get single trajectory
[x,P]=extended_kalman_filter(model,x0,P0,y);


% Allocate set of points 
[L,pp]=chol(P,'lower');
if pp>0
    [V,DD]=eig(P);
    d=diag(DD);
    d=sqrt(max(d,0));
    L=V*diag(d);
end

Cx=L*Cu+repmat(x,1,size(Cu,2));

% Deploy Full Bayesian on the allocated points
Px=priv_compute_aposteriori(Cx0,Px0,Cx,y,model);

end
%-----------------------------------------------
function [mu,sigma]=compute_mean_variance(Cx,Px)
%COMPUTE_MEAN_VARIANCE compute the mean and variance of a point
%distribution.
mu=Cx*Px(:);
mx=size(Cx,1);
sigma=zeros(mx);
sigma_tmp=Cx-repmat(mu,1,size(Cx,2));
for ii=1:size(Cx,2)
    sigma=sigma+Px(ii)*sigma_tmp(:,ii)*sigma_tmp(:,ii)';
end
end
%-----------------------------------------------
function [x,P]=extended_kalman_filter(model,x0,P0,y)

A=jaccsd(model.f,x0);    %nonlinear update and linearization at current state
x1=real(model.f(x0));
P=A*P0*A'+model.Q;                 %partial update
H=jaccsd(model.h,x1);    %nonlinear measurement and linearization
z1=real(model.h(x1));
P12=P*H';                   %cross covariance
R=chol(H*P12+model.R);            %Cholesky factorization

U=P12/R;                    %K=U/R'; Faster because of back substitution
x=x1+U*(R'\(y-z1));         %Back substitution to get state update
P=P-U*U';                   %Covariance update, U*U'=P12/R/R'*P12'=K*P12.
end
%-----------------------------------------------
function A=jaccsd(fun,x)
% JACCSD Jacobian through complex step differentiation
% [z J] = jaccsd(f,x)
% z = f(x)
% J = f'(x)
%
z=fun(x);
n=numel(x);
m=numel(z);
A=zeros(m,n);
h=n*eps;
for k=1:n
    x1=x;
    x1(k)=x1(k)+h*1i;
    A(:,k)=imag(fun(x1))/h;
end
end
%-----------------------------------------------
function [Px] = priv_compute_aposteriori(Cx0,Px0,Cx,y,model)

m=size(Cx,2);
Px=zeros(m,1);
    for ii=1:m
        dx=repmat(Cx(:,ii),1,size(Cx0,2))-model.f(Cx0);
        Px(ii)=model.pw(dx)*Px0(:);
    end
    dy=repmat(y,1,m)-model.h(Cx);
    Py=model.pv(dy);
    if sum(Px)==0
        Px=Py(:);
    else
        Px=Px.*Py(:);
    end
    Px=Px(:)/sum(Px(:));

end