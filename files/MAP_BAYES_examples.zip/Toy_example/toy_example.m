% Mixing Maximum a Posteriori and Full bayesian estimation using Vector
% Quatizer (VQ)
clear
clc

% Simulation parameter
Nx_upper_bound=15;      % number of vector used to quantize M(x) 
N=100;      % Number of samples


% Model parameters
mx=2; % size of state vector
my=1; % size of output vector
Nh=1; % size of rolling horizon % for EKF-Bayes it is always 1.
model.Q=0.1*eye(mx);
model.R=1e-2*eye(my);

% initial condition
x0=ones(mx,1);
P0=eye(mx);

 % Probability density functions of v and w
model.pw=@(x)(real(exp(-0.5*quad_expr(x,model.Q)))); % Normal distribution
model.pv=@(x)(real(exp(-0.5*quad_expr(x,model.R))));

% nonlinear functions  
model.f=@(x) ([0.99*x(1,:)+0.1*x(2,:);-0.1*x(1,:)+0.5*x(2,:)./(1+(x(2,:)).^2)]);
model.h=@(x) ((x(1,:)-3*x(2,:)));

% ---- Generate signals ---------------
 w=chol(model.Q,'lower')*randn(mx,N);
 v=chol(model.R,'lower')*randn(my,N);

 % 
 x=zeros(mx,N+1);
 y=zeros(my,N);
% 
 for t=1:N
     x(:,t+1)=model.f(x(:,t))+w(:,t);
     y(:,t)=model.h(x(:,t))+v(:,t);
 end

% Off-line computations
[Pu,Cu]=Initialize_MAP_Bayes_quantization(Nx_upper_bound,mx);
Nx=length(Pu);
 
% Point distribution for x0
Cx0=chol(P0,'lower')*Cu;
Px0=Pu;

%---Rolling horizon simulation---

Posteriori_dist_x=zeros(Nx*mx,N);
Posteriori_dist_p=zeros(Nx,N);
x_mean=zeros(mx,Nh);
x_map=zeros(mx,N);
for k=Nh+1:N
    
    y_rh=y(:,k); % get current measurement
    
    % estimate current state a-posteriori PDF.
    [Cx,Px]=ekf_bayes_update(model,Cx0,Px0,y_rh,Cu);
    
    % get mean value 
    x_mean(:,k)=Cx*Px;
    
    % get max value
    [~,idx_max]=max(Px);
    x_map(:,k)=Cx(:,idx_max);
     
    % Store a-posteriori PDF
    Posteriori_dist_x(:,k)=Cx(:);
    Posteriori_dist_p(:,k)=Px;
    
end

%---- Generate plots-----
figure(1)
line_colors=hsv(3);
% True Values
for ii=1:mx
    subplot(mx,1,ii);
    hold off
    line(0:N,x(ii,:),'DisplayName','true value','Color',line_colors(1,:))
    title(['Estimated values for x_' num2str(ii)]);
    xlabel('Time [s]')
end
% Estimates by Mean Value
for ii=1:mx
    subplot(mx,1,ii);
    hold on
    line(1:N,x_mean(ii,:),'DisplayName','estimated mean','Color',line_colors(2,:))
    hold off
end
% Estimates by MAP
for ii=1:mx
    subplot(mx,1,ii);
    hold on
    line(1:N,x_map(ii,:),'DisplayName','estimated MAP','Color',line_colors(3,:))
    hold off
    legend('Location','Best')
end
