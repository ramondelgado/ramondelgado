function [s] = compute_skewness(Cx,Px,mu,sigma)%#codegen
%COMPUTE_SKEWNESS Compute skewness, given the pointwise probability denfity
%function.
s=0;
xc=Cx-repmat(mu,1,size(Cx,2));
for ii=1:size(Cx,2)
    for jj=1:size(Cx,2)
        s = s + Px(ii)*Px(jj)*((xc(:,ii)'/sigma)*xc(:,jj))^3;
    end
end
end

