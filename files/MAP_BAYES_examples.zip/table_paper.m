function [ ] =table_paper(data,R)
% PLOTS_PAPER Generate some of the plots in the paper

nx=size(data.x,1);
% find Full Bayesian results
for ii=1:length(R)
    if strcmpi(R{ii}.short_name,'fb')
        fb_idx=ii;
        break
    end
end

my_flag=true;
fprintf('\nMean Square Error with respect to the "true values" of the mean,\n')
fprintf('mode, variance and skewness from the Full Bayesian Filtering\n')
fprintf('\nMethod\tmean\tmode\tvar\tskew\n')
for ii=1:length(R)
    if ii~=fb_idx
        % MSE of the mean
        e=abs(R{ii}.results.stats.mean-R{fb_idx}.results.stats.mean);
        e_mean=sum(e(:).^2)/length(data.t);
        
        % MSE of the mode
        e=abs(R{ii}.results.stats.mode-R{fb_idx}.results.stats.mode);
        e_mode=sum(e(:).^2)/length(data.t);
        
        if nx==1
            % MSE of the variance
            e=abs(R{ii}.results.stats.variance-R{fb_idx}.results.stats.variance);
            e_variance=sum(e.^2)/length(data.t);
            
            % MSE of the Skewness
            e=abs(R{ii}.results.stats.skew-R{fb_idx}.results.stats.skew);
            e_skew=sum(e.^2)/length(e);
        else
            e_variance=nan;
            e_skew=nan;
        end
        
        % print MSE values
        fprintf('%s\t%3.5f\t%3.5f\t%3.5f\t%3.5f\n',R{ii}.short_name,e_mean,e_mode,e_variance,e_skew)
        if my_flag
            my_flag=false;
        end
    end
end