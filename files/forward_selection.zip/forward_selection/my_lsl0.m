function [x_opt,d_idx] = my_lsl0(y,A,k)
%MY_LSL0 Provide a suboptimal solution to a L0 constrained Least squares
%problem
% Minimize (y-A*x)'*(y-A*x)
% subject to |x|_0<=k
%
% Usage [x_opt] = my_lsl0(y,A,k)
%
% Ramon A. Delgado
% January 2016
TolZero=1e-6;
x_ls=A\y;
rho=abs(x_ls'*A'*y)/TolZero;

nx=size(A,2);
ny=size(A,1);
AA=A'*A;

% Initialize Algorithm
Z=(AA/rho+eye(nx))\eye(nx);
x=Z*A'*y/rho;

d_idx=[];       % selected dictionary elements
dn_idx=1:nx;    % non-selected dictionary elements
for ii=1:k
   
    % compute reduction on Least Squares cost
    diagZ=diag(Z);
    reduction=(x(dn_idx).^2)./(1-diagZ(dn_idx));
    
    % select a column of A
    [~,idx_max]=max(reduction);
    
    idx_selected=dn_idx(idx_max(1));
    
    % Update estimate
    s=Z(:,idx_selected)/(1-diagZ(idx_selected));
    x=x+s*x(idx_selected);
    Z=Z+s*Z(idx_selected,:);

    % update indicies
    d_idx=[d_idx idx_selected];
    dn_idx=dn_idx(~(dn_idx==idx_selected));    
end

x_opt=zeros(nx,1);
x_opt(d_idx)=x(d_idx);
end


