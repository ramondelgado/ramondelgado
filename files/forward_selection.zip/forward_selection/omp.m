function [x,res] = omp(y,A,k)
% Provide a suboptimal solution to a L0 constrained Least squares
%problem using Orthogonal Matching Pursuit
[ny,nx] = size(A);
x = zeros(nx,1);
res = y;
support = []; % empty support
for i=1:k
    % compute correlation between residual and columns of A
    corr = A'*res;
    % find position n (and value c) of the maximally correlated column
    [~,n] = max(abs(corr));
    % extend the support
    support(end+1) = n;
    % update the representation
    x(support) = pinv(A(:,support))*y;
    % update the residual
    res = res - A(:,support)*x(support);
end

