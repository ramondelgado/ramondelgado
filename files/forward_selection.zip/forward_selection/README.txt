README

This zip file contains the code necessary to run the numerical comparison in the paper:

Ramon Delgado. "Cardinality-Constrained Least Squares vis a Forward Selection Algorithm"

for each value of "m" and "n" run the matlab script comparison_example.m

The proposed forward selection algorithm is implemented in my_LSL0.m 
