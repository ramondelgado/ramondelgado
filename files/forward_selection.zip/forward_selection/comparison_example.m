% Comparison Example
% Compare Different methods to solve the problem 
% min |y-A*x|_2
% s.t. x>=0
%       |x|_0<=nk
% Ramon A. Delgado 
% January 2016

clear
clc

ny=1000; 
nx=10;
nk=floor(min(ny,nx)/2);

%nomalize A?
normalizeA=true;

Nsim=100;     % Number of Monte Carlo Simulations

jj=0;

% %Define methods to consider
% Orthogonal Mathcing Pursuit
jj=jj+1;
Method{jj}.name='OMP';
Method{jj}.call=@(y,A,nk) (omp(y,A,nk));
Method{jj}.x=nan(nx,Nsim);
Method{jj}.cost=nan(Nsim,1);
Method{jj}.time=nan(Nsim,1);

%Mathcing Pursuit
jj=jj+1;
Method{jj}.name='MP';
Method{jj}.call=@(y,A,nk) (mp(y,A,nk));
Method{jj}.x=nan(nx,Nsim);
Method{jj}.cost=nan(Nsim,1);
Method{jj}.time=nan(Nsim,1);


%Proposed Forward Selection for Least Squares
jj=jj+1;
Method{jj}.name='MY LSL0';
Method{jj}.call=@(y,A,nk) (my_lsl0(y,A,nk));
Method{jj}.x=nan(nx,Nsim);
Method{jj}.cost=nan(Nsim,1);
Method{jj}.time=nan(Nsim,1);

% Orthogonal Least Squares
jj=jj+1;
Method{jj}.name='OLS';
Method{jj}.call=@(y,A,nk) (my_ols(y,A,nk));
Method{jj}.x=nan(nx,Nsim);
Method{jj}.cost=nan(Nsim,1);
Method{jj}.time=nan(Nsim,1);


% Initialize storage variables
cost=nan(Nsim,length(Method));
run_time=nan(Nsim,length(Method));
indices=nan(nx,length(Method),Nsim);
rng('default')

% Start Monte Carlos simulations
for ii=1:Nsim
    
    A=randn(ny,nx);
    if normalizeA
        A=A*diag(1./sqrt(sum(A.^2,1)));
    end
    y=randn(ny,1);
    
    % Estimate x
    for mm=1:length(Method)
        fprintf('%s\n',Method{mm}.name)
        if isfield(Method{mm},'initial_method')
            x_init=Method{Method{mm}.initial_method}.x(:,ii);
            tic
            x_tmp=Method{mm}.call(y,A,nk,x_init(1:nx));
            t_tmp=toc;
            
        else
            tic
            x_tmp=Method{mm}.call(y,A,nk);
            t_tmp=toc;
        end
        % Save current estimate
        Method{mm}.x(1:nx,ii)=x_tmp;
        cost(ii,mm)=norm(y-A*x_tmp);
        run_time(ii,mm)=t_tmp;
        Method{mm}.cost(ii)=cost(ii,mm);
        Method{mm}.time(ii)=t_tmp;
        [~,idx_tmp]=sort(abs(x_tmp),'descend');
        indices(1:nk,mm,ii)=sort(idx_tmp(1:nk));
        norm(y-A*x_tmp)
    end
end

% Display simulation results
fprintf('Results with ny=%d, nx=%d, nk=%d\n',ny,nx,nk)
fprintf('%25s\t cost  \t\t\t\truntime \n\n','Method')
for ii=1:length(Method)
    fprintf(['%25s\t%2.5f' char(177) '%2.3f\t\t\t%2.5f' char(177) '%2.4f\n'],Method{ii}.name,mean(Method{ii}.cost),std(Method{ii}.cost),mean(Method{ii}.time),std(Method{ii}.time));
end
