function [x_opt,support] = my_ols(y,A,k)
%MY_OLS Implements Orthogonal Least Squares
% Usage [x_opt,support]=my_ols(y,A,k)
%
% Implements Orthogonal Least Squares as described in
% S. Chen, C.F.N. Cowan and P.M Grant
% "Orthogonal Least Squares Learning Algorithm for Radial Basis Fuction
% Networks"
nx=size(A,2);

% Initialize algorithm
w=A;
g=(w*diag(1./(sum(w.^2,1))))'*y;
e=g.^2.*(sum(w.^2,1).')./(y'*y);
[~,ii_selected]=max(e);
w=A(:,ii_selected);

non_support=1:nx; 
non_support=non_support(non_support~=ii_selected);
support=[ii_selected];

% Start Iterations
termination=false;
while ~termination
    
    Alpha=((w*diag(1./(sum(w.^2,1)))))'*A(:,non_support);
    w_inner=A(:,non_support)-w*Alpha;
    g=(w_inner*diag(1./(sum(w_inner.^2,1))))'*y;
    e=(1/(y'*y))*g.^2.*(sum(w_inner.^2,1).');
    
    % Select minimum cost
    [~,ii_max]=max(e);
    ii_selected=non_support(ii_max);
    
    % Update w
    w=[w w_inner(:,ii_max)];
    
    % update support
    non_support=non_support(non_support~=ii_selected);
    support=[support ii_selected];
    
    % check termination criterion
    if length(support)>=k
        termination=true;
    end
end
x_opt=zeros(nx,1);
x_opt(support)=A(:,support)\y;

end

