function [x,res] = mp(y,A,k)
% Provide a suboptimal solution to a L0 constrained Least squares
%problem using Matching Pursuit
[ny,nx] = size(A);
x = zeros(nx,1);
res = y;
for i=1:k
    % compute correlation between residual and columns of A
    corr = A'*res;
    % find the column that is maximally correlated with the residual
    [~,n] = max(abs(corr));
    % update the representation
    x(n) = x(n) + corr(n);
    % update residual
    res = res - corr(n)*A(:,n);
end

